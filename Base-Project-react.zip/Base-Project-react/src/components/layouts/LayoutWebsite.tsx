const LayoutWebsite = () => {
    return <div>LayoutWebsite</div>;
};

export default LayoutWebsite;
